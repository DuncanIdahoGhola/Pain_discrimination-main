# Pain_discrimination
Pain Learning Lab Pain_discrimination Project 

To run analysis, go to VENV folder and run Analyses_USE THIS after changing BIDSROOT
